<?php 
   $host = 'localhost';
   $username = 'root';
   $password = '';
   $db = 'client_20';

   $conn = mysqli_connect($host, $username, $password, $db);
?>